function DeathScreen(x,y,w,l,txt,cl,cl2,cl3){
	  this.x=x;
  this.y=y;
  this.txt=txt;
  this.cl=cl;
  this.cl2=cl2;
  this.w=w;
  this.l=l;
  this.cl3=cl3;
  
  this.display=function(){
  push();
  fill(this.cl);
  rect(this.x,this.y,this.w,this.l);
  fill(this.cl2);
  textSize(60);
  text(this.txt,this.w/2-125,this.l/2-100);
    noStroke();
  rect(this.x+this.w/2-50,this.y+this.l/2,100,50);
  fill(cl3);
  rect(this.x+this.w/2-25,this.y+this.l/2+10,50,25);
  if (mouseX>this.x+this.w/2-25 && mouseX<this.x+this.w/2+50 && mouseY>this.y+this.l/2+10 && mouseY<this.y+this.l/2+10+25){
   	fill(0,0,0,100);
   rect(this.x+this.w/2-25,this.y+this.l/2+10,50,25);
   b1=true
  }
    if (b1==true && mouseIsPressed)
    {Initialization()}
      }
  pop();
}