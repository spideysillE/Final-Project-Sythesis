function Hook(x,y,w,h,clr,hcl,sz){
  this.clr=clr;
  this.hcl=hcl;
  this.x=x;
  this.y=y;
  this.w=w;
  this.h=h;
  this.sz=sz;
  
  this.display=function(){ 
  push();
  noStroke();
  fill(this.clr);
  rect(this.x,this.y,this.w,this.h);
  fill(this.hcl);
  ellipse(this.x-15,this.h,this.sz);
  fill('blue');
  ellipse(this.x-19,this.h-5,this.sz-2);
  pop();
  }
}