function Fish(x,y,cl,cl2,sz){
this.x=x;
this.y=y;
this.cl=cl;
this.sz=sz;
this.cl2=cl2;


  this.display=function(){
  push();
  noStroke();
  fill(this.cl);
  ellipse(this.x,this.y,this.sz);
  rect(this.x-20,this.y-10,this.sz,this.sz,this.h);
  triangle(this.x-40,this.y-10,this.x,this.y,this.x-40,this.y+10);
  fill(this.cl2);
  ellipse(this.x,this.y,8);
  pop();

		  }
  
  this.moveY = function(y) {
    this.y=this.y+y;
    if (this.y>height) {
      this.y=height-(y/2)-1;
    }
    else if(this.y<110) {
      this.y=(y/2)+110;
    }
  }
}