function Initialization(){
fish= new Fish(150,150,'gold','white',20); 
	  hook= new Hook(380,0,3,150,'brown','grey',40);//h value
  carol=new Coral(340,250,40,200,'pink','red','white'); //y value
  gameState=0
}