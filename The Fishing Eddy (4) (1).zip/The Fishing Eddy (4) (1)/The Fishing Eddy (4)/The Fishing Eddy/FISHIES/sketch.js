var gameState=0;
 var myWaves=[]
  var waves = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,
              20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36];

function setup() { 
  createCanvas(400, 400);
  
  dedscreen = new DeathScreen(0,0,400,400,'You Dead','black','red','yellow');
  inscreen = new IntroScreen(0,0,400,400,'cyan','blue','red','BEGIN');
  skiundsee= new SkyAndSea(50,'white','blue',30);
  Initialization();
  wavves= new Waves(i*50,50,100,waves[i]);
  for(var i=0; i<waves.length; i++) {
      myWaves[i] = new Waves(i*50,50,65);}//,waves[i]);}
} 

function draw() {
  if(gameState==0){
  inscreen.display();
  }
  
  //if(gameState==1){
  //				EntireGame()
 // }
  
  if(gameState==2){
  dedscreen.display();
 }
   
  if(gameState==1){
skiundsee.display();
    
  
fish.display();
   if (keyIsPressed) {
    if (keyCode == UP_ARROW) {
      fish.moveY(-5)
    } 
    else if (keyCode == DOWN_ARROW) {
      fish.moveY(5)
    }
     //if (this.x+10==Coral(this.x,this.y,this.w,this.l)){}
  }
 if(fish.x+8>hook.x && fish.x<hook.x+hook.w && fish.y<hook.y+hook.h+hook.sz){
   gameState=2
 }
    
 if(fish.x+8>carol.x-10 && fish.x<carol.x+carol.w+25 && fish.y>carol.y){
   gameState=2
}
    
hook.display();
carol.display();  
carol.x=carol.x-5
  hook.x=hook.x-5
  if (hook.x==-45)
  {hook.x=450
  carol.x=410
   var depth= random(110,300);
   hook.h= depth
   carol.y= depth+100
  }
  
wavves.display();
  for(var i=0; i<myWaves.length; i++){
  myWaves[i].x=myWaves[i].x-1
  if (myWaves[i].x==-45)
  {myWaves[i].x=450}
  }
		 }
}