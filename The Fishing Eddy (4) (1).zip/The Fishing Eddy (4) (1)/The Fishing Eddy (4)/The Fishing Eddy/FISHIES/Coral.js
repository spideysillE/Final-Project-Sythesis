function Coral(x,y,w,l,cl,cl2,cl3){
  this.x=x
  this.y=y
  this.w=w
  this.l=l
  this.cl=cl
  this.cl2=cl2
  this.cl3=cl3
 
  this.display=function(){
  push();
  noStroke();
  fill(this.cl)
  rect(this.x+10,this.y+40,this.w,this.l);
  fill(this.cl2);
  rect(this.x-10,this.y+5,this.w,this.l/2);
  fill(this.cl3)
  ellipse(this.x,this.y+10,7);
  ellipse(this.x+5,this.y+35,7);
  ellipse(this.x+7,this.y+70,7);
  ellipse(this.x+20,this.y+100,7);
  ellipse(this.x+20,this.y+100,7);
  ellipse(this.x+35,this.y+140,7);
  ellipse(this.x+50,this.y+120,7);
  pop();
  }
}
