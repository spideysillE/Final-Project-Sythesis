function SkyAndSea(sealv,skycl,seacl,sz){
this.sealv=sealv;
this.skycl=skycl;
this.seacl=seacl;
this.sz=sz;

  //var myWaves=[]
 // var waves = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,
              //20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36];
  this.display=function(){
  push();
  noStroke();
  fill(this.skycl);
  rect(0,0,400,this.sealv);
  fill(this.seacl);
  rect(0,this.sealv,400,400);
  fill(this.skycl);
  for(var i=0; i<myWaves.length; i++) {
    myWaves[i].display();// = new Waves(i*50,50,100,waves[i]);
  
 // function Waves(x,sealv,sz){
  //  this.x=x;
    //this.sealv=sealv;
    //this.sz=sz;
    
    //push();
    //ellipse(this.x,this.sealv,this.sz);
    //pop();
  
  }
 }
}