
  function Waves(x,sealv,sz){
    this.x=x;
    this.sealv=sealv;
    this.sz=sz;
    
    this.display=function(){
    push();
    ellipse(this.x,this.sealv,this.sz);
    pop();
    }
  }